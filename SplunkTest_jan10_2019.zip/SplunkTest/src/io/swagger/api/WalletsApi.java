package io.swagger.api;

//import io.swagger.model.*;
import io.swagger.api.WalletsApiService;
import io.swagger.api.factories.WalletsApiServiceFactory;

import io.swagger.annotations.ApiParam;
//import io.swagger.jaxrs.*;

import io.swagger.api.NotFoundException;


import java.io.PrintWriter;
import java.io.StringWriter;


import com.fasterxml.jackson.annotation.JsonInclude;

import javax.servlet.ServletConfig;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.*;

//import org.apache.logging.log4j.*;
import com.splunk.logging.*;
import org.apache.logging.log4j.*;

@Path("/logtosplunk")

@JsonInclude(JsonInclude.Include.NON_NULL)
@io.swagger.annotations.Api(description = "the wallets API")
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2018-06-06T22:42:42.640Z")
public class WalletsApi  {
	   @JsonInclude(JsonInclude.Include.NON_NULL)
   private final WalletsApiService delegate;
	
	   public static  org.apache.logging.log4j.core.LoggerContext contxt=	  new org.apache.logging.log4j.core.LoggerContext("http-input");
   static Logger  m_log = null;
   
   public static void initIPgloging(){
	    m_log = contxt.getLogger("http-input");		 
		m_log.info(" Starting to test splunk log----  : " );
		}
   public WalletsApi(@Context ServletConfig servletContext) {
      WalletsApiService delegate = null;

      if (servletContext != null) {
         String implClass = servletContext.getInitParameter("WalletsApi.implementation");
         if (implClass != null && !"".equals(implClass.trim())) {
            try {
               delegate = (WalletsApiService) Class.forName(implClass).newInstance();
            } catch (Exception e) {
               throw new RuntimeException(e);
            }
         } 
      }

      if (delegate == null) {
         delegate = WalletsApiServiceFactory.getWalletsApi();
      }

      this.delegate = delegate;
   }

       @GET
    @Path("/{emailID}/brand/{brandId}")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
	@JsonInclude(JsonInclude.Include.NON_NULL)
    @io.swagger.annotations.ApiOperation(value = "", notes = "Add a single 'Wallet' object.", response = String.class, tags={ "Wallet APIs", })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "Successful response", response = String.class),
        
        @io.swagger.annotations.ApiResponse(code = 304, message = "Not Modified", response = String.class),
        
        @io.swagger.annotations.ApiResponse(code = 400, message = "Bad Data", response = String.class),
        
        @io.swagger.annotations.ApiResponse(code = 404, message = "Not found", response = String.class),
        
        @io.swagger.annotations.ApiResponse(code = 422, message = "Unprocessable Entity", response = String.class),
        
        @io.swagger.annotations.ApiResponse(code = 500, message = "Internal Server Error", response = String.class) })
    public Response walletsExternalReferenceIDCardsPost(@ApiParam(value = "email id",required=true) @PathParam("emailID") String emailID
,@ApiParam(value = "brand id",required=true) @PathParam("brandId") String brandId
,@Context SecurityContext securityContext)
    throws NotFoundException {

    	
    	
    	String str_response ="Request email:"+emailID+"AND brand:"+brandId;
		try {
			initIPgloging();
			m_log.info("emailID ---  : "+emailID );
			m_log.info("brandId ---  : "+brandId );
			m_log.info("str_response ---  : "+str_response );
			
		} catch (Exception e) {
			str_response = str_response+"Exception....."+getErrorStackTrace(e);
		}		    	
		return Response.status(200).entity(str_response).build();
		//return Response.ok().entity(res).build();
    }
       
       public static String getErrorStackTrace(Exception e){
   		String str_error_message = "";
   		StringWriter sw = new StringWriter();
   		PrintWriter pw = new PrintWriter(sw);
   		e.printStackTrace(pw);
   		String sStackTrace = sw.toString(); // stack trace as a string
   		return sStackTrace;

   	}
   
}
